package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView textView = findViewById(R.id.textView);
        EditText egyiksz = findViewById(R.id.editTex);
        EditText masiksz=findViewById(R.id.editTextNumber4);
        Button osszead=findViewById(R.id.buttonoosszead);
        Button kivon=findViewById(R.id.buttonkivon);
        Button szoroz=findViewById(R.id.buttonszorzas);
        Button oszt=findViewById(R.id.buttonosztas);
        osszead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    int firsNumber=Integer.parseInt(egyiksz.getText().toString());
                    int secoundNumber=Integer.parseInt(masiksz.getText().toString());

                    add(firsNumber,secoundNumber,textView);

                }
                catch (Exception e){

                }

            }
        });
        kivon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    int firsNumber=Integer.parseInt(egyiksz.getText().toString());
                    int secoundNumber=Integer.parseInt(masiksz.getText().toString());

                    subtract(firsNumber,secoundNumber,textView);

                }
                catch (Exception e){

                }

            }
        });
        szoroz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    int firsNumber=Integer.parseInt(egyiksz.getText().toString());
                    int secoundNumber=Integer.parseInt(masiksz.getText().toString());

                    multiply(firsNumber,secoundNumber,textView);

                }
                catch (Exception e){

                }
            }
        });
        oszt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    int firsNumber=Integer.parseInt(egyiksz.getText().toString());
                    int secoundNumber=Integer.parseInt(masiksz.getText().toString());

                    divide(firsNumber,secoundNumber,textView);

                }
                catch (Exception e){

                }
            }
        });


    }
    public void multiply(int firstNumber, int secondNumber, TextView textView) {
        textView.setText(String.valueOf(firstNumber * secondNumber));
    }

    public void divide(int firstNumber, int secondNumber, TextView textView) {
        textView.setText(String.valueOf(firstNumber / secondNumber));
    }

    public void add(int firstNumber, int secondNumber, TextView textView) {
        textView.setText(String.valueOf(firstNumber + secondNumber));
    }

    public void subtract(int firstNumber, int secondNumber, TextView textView) {
        textView.setText(String.valueOf(firstNumber - secondNumber));
    }


}