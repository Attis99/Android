package com.example.mypizzaapp;

import java.io.Serializable;

public class Pizza implements Serializable {
    private int image;
    private String name;
    private String info;
    private double price;

    public Pizza(int image, String name, String info, double price) {
        this.image = image;
        this.name = name;
        this.info = info;
        this.price = price;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
