package com.example.mypizzaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editTextNev = findViewById(R.id.editTextNev);

        Button rendelesGomb = findViewById(R.id.rendelesGomb);

        rendelesGomb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextNev.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Kérem adja meg a nevét!", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(MainActivity.this, PizzaTabs.class);
                    startActivity(intent);
                }
            }
        });
    }
}