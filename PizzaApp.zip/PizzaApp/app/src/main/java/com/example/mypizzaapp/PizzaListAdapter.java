package com.example.mypizzaapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PizzaListAdapter extends RecyclerView.Adapter<PizzaListAdapter.VH> {

    private Activity context;
    private List<Pizza> list;

    public PizzaListAdapter(Activity context, List<Pizza> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rootView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row, parent, false);
        return new VH(rootView, context);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        Pizza pizza = list.get(position);
        holder.rootView.setTag(pizza);
        holder.image.setImageResource(pizza.getImage());
        holder.name.setText(pizza.getName());
        holder.info.setText(pizza.getInfo());
        holder.price.setText(String.valueOf(pizza.getPrice()));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class VH extends RecyclerView.ViewHolder {
        final View rootView;
        final ImageView image;
        final TextView name;
        final TextView info;
        final TextView price;

        public VH(@NonNull View itemView, final Context context) {
            super(itemView);
            rootView = itemView;
            image = itemView.findViewById(R.id.pizzaKep);
            name = itemView.findViewById(R.id.pizzaNev);
            info = itemView.findViewById(R.id.pizzaInfo);
            price = itemView.findViewById(R.id.pizzaAr);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, PizzaDetails.class);
                    image.buildDrawingCache();
                    Bitmap image1 = image.getDrawingCache();

                    Bundle extras = new Bundle();
                    extras.putParcelable("image", image1);

                    intent.putExtras(extras);
                    intent.putExtra("name", name.getText().toString());
                    intent.putExtra("info", info.getText().toString());
                    intent.putExtra("price", price.getText().toString());
                    context.startActivity(intent);
                }
            });
        }
    }
}
