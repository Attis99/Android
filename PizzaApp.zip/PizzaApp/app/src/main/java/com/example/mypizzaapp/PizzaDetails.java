package com.example.mypizzaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.logging.Logger;

public class PizzaDetails extends AppCompatActivity {

    RadioButton meretRadioButton;
    RadioGroup meretekGroup;
    double valasztottMeret = 0;
    double osszeg = 0;
    double feltetAr = 0;
    boolean checkedSajt = false;
    boolean checkedKetchup = false;
    boolean checkedKukorica = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza_details);

        getSupportActionBar().setTitle("PizzaDetails");

        SharedPreferences preferences = getApplicationContext().getSharedPreferences("MyPref", 0);

        ImageView pizzaKep = findViewById(R.id.pizzaKep2);
        TextView pizzaNev = findViewById(R.id.pizzaNev2);
        TextView pizzaInfo = findViewById(R.id.pizzaInfo2);
        TextView pizzaAr = findViewById(R.id.pizzaAr2);
        TextView teljesArTv = findViewById(R.id.teljasArTv);
        Button rendelesBt = findViewById(R.id.rendelesBt);

        Bitmap bmp = getIntent().getExtras().getParcelable("image");
        pizzaKep.setImageBitmap(bmp);
        pizzaNev.setText(getIntent().getExtras().getString("name"));
        pizzaInfo.setText(getIntent().getExtras().getString("info"));
        pizzaAr.setText(getIntent().getExtras().getString("price"));

        teljesArTv.setText(preferences.getString("osszeg", "0"));

        RadioGroup meretekGroup = findViewById(R.id.meretekGroup);

        rendelesBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context;
                SharedPreferences preferences = getApplicationContext().getSharedPreferences("MyPref", 0);
                Editor editor = preferences.edit();


                osszeg = Double.parseDouble(pizzaAr.getText().toString());
                osszeg += feltetAr;
                osszeg += valasztottMeret;

                editor.putString("osszeg", String.valueOf(osszeg));
                editor.commit();
                teljesArTv.setText(String.valueOf(osszeg));
            }
        });

        meretekGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radioKicsi:
                        meretRadioButton = findViewById(R.id.radioKicsi);
                        Toast.makeText(PizzaDetails.this, meretRadioButton.getText().toString(), Toast.LENGTH_SHORT).show();
                        feltetAr = 0;
                        valasztottMeret = 10;
                        break;
                    case R.id.radioKozepes:
                        meretRadioButton = findViewById(R.id.radioKozepes);
                        Toast.makeText(PizzaDetails.this, meretRadioButton.getText().toString(), Toast.LENGTH_SHORT).show();
                        feltetAr = 0;
                        valasztottMeret = 20;
                        break;
                    case R.id.radioNagy:
                        meretRadioButton = findViewById(R.id.radioNagy);
                        Toast.makeText(PizzaDetails.this, meretRadioButton.getText().toString(), Toast.LENGTH_SHORT).show();
                        feltetAr = 0;
                        valasztottMeret = 30;
                        break;

                }
            }
        });
    }

    public void onCheckBoxClicked(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        switch (view.getId()) {
            case R.id.checkSajt:
                if (checked) {
                    feltetAr += 1;
                    checkedSajt = true;
                } else {
                    if (checkedSajt) {
                        feltetAr -= 1;
                        checkedSajt = false;
                    }
                }
                break;
            case R.id.checkKetchup:
                if (checked) {
                    feltetAr += 2;
                    checkedKetchup = true;
                } else {
                    if (checkedSajt) {
                        feltetAr -= 2;
                        checkedKetchup = false;
                    }
                }
                break;
            case R.id.checkKukorica:
                if (checked) {
                    feltetAr += 3;
                    checkedKukorica = true;
                } else {
                    if (checkedSajt) {
                        feltetAr -= 3;
                        checkedKukorica = false;
                    }
                }
                break;
        }
        Log.d("osszeg", String.valueOf(feltetAr));
    }
}