package com.example.mypizzaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class PizzaTabs extends AppCompatActivity {
    FragmentManager manager;
    FragmentTransaction transaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza_tabs);

        getSupportActionBar().setTitle("PizzaTabs");

        TabLayout tabLayout = findViewById(R.id.tabLayout);


        manager = getSupportFragmentManager();
        transaction = manager.beginTransaction();

        transaction.replace(R.id.fragmentContainer, new PizzaListFragment());

        transaction.commit();

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                manager = getSupportFragmentManager();
                transaction = manager.beginTransaction();

                int position = tab.getPosition();

                if (position == 0) {
                    transaction.replace(R.id.fragmentContainer, new PizzaListFragment());
                } else {
                    transaction.replace(R.id.fragmentContainer, new RendelesekFragment());
                }
                transaction.commit();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
}