package com.example.fregmentek;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        FragmentManager fragmentManager = getSupportFragmentManager();
        int disp=getResources().getConfiguration().orientation;
        if (disp==1){
            fragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainerView2, UjFragment.class, null)
                    .setReorderingAllowed(true)
                    .addToBackStack("name") // name can be null
                    .commit();
        }
        else {
            fragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainerView2, pirosFragment.class, null)
                    .setReorderingAllowed(true)
                    .addToBackStack("name") // name can be null
                    .commit();

        }

    }
}